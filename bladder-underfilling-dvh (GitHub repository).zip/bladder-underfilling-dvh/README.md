# bladder-underfilling-dvh

Code for the paper "Simulation-based assessment of bladder wall DVH robustness to simulated bladder underfilling in prostate VMAT using a single planning CT".

For one patient, the code reads the planning RTSTRUCT and RTDOSE, displaces the bladder dome caudally in 3-mm steps (primary model), derives the 4-mm bladder wall at each level and computes its DVH on the unchanged planned dose. It reports V70Gy, V60Gy and V40Gy (% and cc) and the last level within limits and the first level exceeding a limit (analytical reference limits V70Gy ≤ 25%, V60Gy ≤ 35%, V40Gy ≤ 50%).

## Google Colab

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/MPvivi/bladder-underfilling-dvh/blob/main/bladder_underfilling_colab.ipynb)

1. Open `bladder_underfilling_colab.ipynb` in Colab.
2. Upload the RTDOSE and RTSTRUCT files of one patient to `/content`.
3. Set the bladder and prostate structure names and run all cells.

Or, in any Colab cell:

```
!pip install -q pydicom scikit-image
!python bladder_underfilling.py --dicom_dir /content --bladder Bladder --prostate Prostate
```

## Command line

```
pip install -r requirements.txt
python bladder_underfilling.py --dicom_dir path/to/patient --out results
python bladder_underfilling.py --rtdose RD.dcm --rtstruct RS.dcm --out results
```

| Option | Default | Meaning |
|---|---|---|
| `--dicom_dir` | `/content` in Colab | Folder with the RTDOSE and RTSTRUCT of one patient (searched recursively) |
| `--rtdose`, `--rtstruct` | | Explicit file paths, used instead of `--dicom_dir` |
| `--bladder` | `Bladder` | ROI name of the planning bladder (case-insensitive) |
| `--prostate` | `Prostate` | ROI name of the prostate (CTV) |
| `--step` | `3` | Step of the nominal dome displacement (mm) |
| `--out` | `results` | Output folder |

## Outputs

| File | Content |
|---|---|
| `levels.csv` | One row per level: nominal and effective dome descent, bladder and wall volume, V70Gy/V60Gy/V40Gy in % and cc, limits exceeded |
| `dvh.csv` | Cumulative wall DVH for every level |
| `summary.txt` | Last level within limits and first level exceeding a limit |
| `dvh.png` | Wall DVHs with the reference limits |

## Notes

- The planned dose distribution is not recalculated; it is assumed to stay fixed relative to the prostate. The results describe geometric robustness relative to the planned dose, not the delivered dose.
- The deformation model is voxel-based and not physiological. The limits are analytical reference limits, not validated toxicity thresholds.
- No patient data are included. Do not upload identifiable patient data to public services.
